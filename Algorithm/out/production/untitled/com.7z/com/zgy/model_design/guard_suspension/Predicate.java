package com.zgy.model_design.guard_suspension;

public interface Predicate {
    boolean evaluate();
}
