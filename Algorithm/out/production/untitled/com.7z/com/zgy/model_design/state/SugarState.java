package com.zgy.model_design.state;

public abstract class SugarState {
     public abstract SugarState handle();
}
