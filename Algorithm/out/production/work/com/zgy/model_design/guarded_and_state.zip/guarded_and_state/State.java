package com.zgy.model_design.guarded_and_state;

public abstract class State {

    public abstract void onEmpty();
    public abstract void onHavingPeople();
}
